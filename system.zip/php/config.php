<?php
  define('DB_HOSTNAME','127.0.0.1');
  define('DB_USERNAME', 'root');
  define('DB_PASSWORD', null);
  define('DB_DATABASE', 'mercadorias');
  define('DB_PREFIX','cw');
  define('DB_CHARSET','utf8');
 ?>
